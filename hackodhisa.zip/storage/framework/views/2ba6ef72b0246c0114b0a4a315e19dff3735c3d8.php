<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--Hospital updation forms starts----------------------------------------------------------------------->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Profile Update Form</h4>
            </div>
            <div class="card-body">
                <div class="form-validation">
                    <form action="<?php echo e(route('hos.update.profile')); ?>" method="POST" class="needs-validation" novalidate>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-xl-6">
                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom01">Hospital Name
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input value="<?php echo e($datas['hospital_name']); ?>" name="hospital_name" type="text"
                                            class="form-control" id="validationCustom01"
                                            placeholder="Enter Hospital Name" required>
                                        <div class="invalid-feedback">
                                            Enter valid Hospital Name
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom03">Phone Number
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input value="<?php echo e($datas['username']); ?>" name="contact" disabled type="tel" class="form-control"
                                            id="validationCustom03" placeholder="Enter Your Phone Number" required>
                                        <div class="invalid-feedback">
                                            Enter a valid phone number
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom03">Alternate Contect
                                        Number
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input value="<?php echo e($datas['alter_no']); ?>" name="alter_no" type="tel" class="form-control" id="validationCustom03"
                                            placeholder="Enter Your Phone Number" required>
                                        <div class="invalid-feedback">
                                            Enter a valid Phone number
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-xl-6">
                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom05">Address
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input value="<?php echo e($datas['address']); ?>" name="address" type="text" class="form-control" id="validationCustom06"
                                            placeholder="Street Address " required>
                                        <div class="invalid-feedback">
                                            Please enter a valid address
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom08">Pincode
                                        <span class="text-danger"></span>
                                    </label>
                                    <div class="col-lg-6">
                                        <input value="<?php echo e($datas['pincode']); ?>" name="pincode" type="text" class="form-control" id="validationCustom08"
                                            placeholder="Enter Pincode">
                                        <div class="invalid-feedback">
                                            Enter valid Pincode
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3 row">
                                    <label class="col-lg-4 col-form-label" for="validationCustom07"> Ownership
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-lg-6">
                                        <select  name="ownership" class="default-select wide form-control"
                                            id="validationCustom05">
                                            <option value="<?php echo e($datas['ownership']); ?>" data-display="Select"><?php echo e($datas['ownership']); ?></option>

                                            <option value="govt">Government</option>
                                            <option value="pvt">Private</option>
                                            <option value="trust">Trust</option>
                                        </select>
                                        
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3 row">
                                    <div class="col-lg-8 ms-auto">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\princ\OneDrive\Desktop\hackodhisa\resources\views/hospital/profile.blade.php ENDPATH**/ ?>