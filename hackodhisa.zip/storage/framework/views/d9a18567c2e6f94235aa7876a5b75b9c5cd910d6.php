</div>
</div>


<!--**********************************
    Footer start
***********************************-->
<div class=" text-center">
  <div class="copyright">
    <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2021</p>
  </div>
</div>
<!--**********************************
    Footer end
***********************************-->

<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->


</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<!-- Required vendors -->
<script src="<?php echo e(url('admin/vendor/global/global.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/vendor/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>

<!-- Apex Chart -->
<script src="<?php echo e(url('admin/vendor/apexchart/apexchart.js')); ?>"></script>
<script src=".<?php echo e(url('admin/vendor/nouislider/nouislider.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/vendor/wnumb/wNumb.js')); ?>"></script>

<!-- Dashboard 1 -->
<script src="<?php echo e(url('admin/js/dashboard/dashboard-1.js')); ?>"></script>

<script src="<?php echo e(url('admin/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(url('admin/js/dlabnav-init.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\princ\OneDrive\Desktop\hackodhisa\resources\views/web/footer.blade.php ENDPATH**/ ?>