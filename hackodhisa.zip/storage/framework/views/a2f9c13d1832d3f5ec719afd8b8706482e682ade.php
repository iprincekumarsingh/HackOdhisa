<?php echo $__env->make('layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body style="background-color: #666666;">

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form  action="<?php echo e(route('verify')); ?>" method="post" class="login100-form validate-form">
                    <?php echo csrf_field(); ?>
					<br>
					<span class="login10-form-title p-b-10">
                        Please enter the OTP sent to your number| <?php echo e(session('phone_number')); ?>

					</span>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: Enter 10 digit phone number">
                        <input type="hidden" name="phone_number" value="<?php echo e(session('phone_number')); ?>">
						<input class="input100" type="tel"  name="verification_code">
						<span class="focus-input100"></span>
						<span class="label-input100">Enter you 4 digit OTP</span>
					</div>
                    <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					<br>

					<div class="container-login100-form-btn">
						<button type="submit" class="login100-form-btn">
							Submit OTP
						</button>
					</div>




				</form>

				<div class="login100-more" style="background-image: url('images/Untitled\ \(9\).png');">
				</div>
			</div>
		</div>
	</div>





<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<?php /**PATH C:\Users\princ\OneDrive\Desktop\hackodhisa\resources\views/auth/verify.blade.php ENDPATH**/ ?>