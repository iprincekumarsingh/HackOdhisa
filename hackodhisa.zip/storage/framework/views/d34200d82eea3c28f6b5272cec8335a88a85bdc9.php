
</div></div>
        <!--**********************************
            Footer start
        ***********************************-->

    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(url('admin/vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/vendor/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>

	<!-- Apex Chart -->
	<script src="<?php echo e(url('admin/vendor/apexchart/apexchart.js')); ?>"></script>
	<script src=".<?php echo e(url('admin/vendor/nouislider/nouislider.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/vendor/wnumb/wNumb.js')); ?>"></script>

	<!-- Dashboard 1 -->
	<script src="<?php echo e(url('admin/js/dashboard/dashboard-1.js')); ?>"></script>

    <script src="<?php echo e(url('admin/js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(url('admin/js/dlabnav-init.js')); ?>"></script>


	<script>
		// jQuery(document).ready(function(){
		// 	setTimeout(function() {
		// 		dezSettingsOptions.version = 'dark';
		// 		new dezSettings(dezSettingsOptions);
		// 	},500)
		// });
	</script>
</body>
</html>
<?php /**PATH C:\Users\princ\OneDrive\Desktop\hackodhisa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>